import sys
import time
import sounddevice
from numpy import zeros, float32, concatenate

from pfspeak.common.dataclasses import Recording
from pfspeak.core.core import SpeechToText
from pfspeak.core.stream import Session


def do(session: Session):
    for _ in range(4):
        time.sleep(15)
        partial = session.peek()
        print(partial.text)
    return partial


def nice_wave(recording: Recording):
    waveform = []
    token = recording.tokens[0]
    assert token.start_ts
    currnt_time = token.start_ts

    for chunk in recording.audio:
        gap = chunk.start_time - currnt_time
        if gap > 0:
            padleft = zeros(int(gap * chunk.samplerate), dtype=float32)
            waveform.append(padleft)

        waveform.append(chunk.waveform)

        currnt_time = chunk.end_time
    return concatenate(waveform)

def print_recording(recording: Recording):
    token = recording.tokens[0]
    assert token.start_ts
    offset = - token.start_ts
    start = time.monotonic()

    for token in recording.tokens:

        assert token.start_ts
        while time.monotonic() - start < token.start_ts + offset:
            time.sleep(.001)
        sys.stdout.write(token.text + token.whitespace)
        sys.stdout.flush()
    sys.stdout.write("\n")
    


if __name__ == "__main__":

    stt = SpeechToText()
    with stt.streaming() as session:
        for partial in session.partials():
            newer = do(session)
            session.finalize(newer)
            break
        sys.stdout.write("\n\n")
        sys.stdout.flush()
        recording = session.recordings


    for recording in session.recordings:
        waveform = nice_wave(recording)
        time.sleep(2)
        sounddevice.play(waveform, samplerate=16_000)
        print_recording(recording)


